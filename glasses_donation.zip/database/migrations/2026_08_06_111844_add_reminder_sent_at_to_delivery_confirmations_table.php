<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('delivery_confirmations', function (Blueprint $table) {
            // تاريخ إرسال تذكير "لم يؤكد الاستلام منذ 3 أيام" - يمنع تكرار الإرسال
            $table->timestamp('reminder_sent_at')->nullable()->after('recipient_responded_at');
        });
    }

    public function down(): void
    {
        Schema::table('delivery_confirmations', function (Blueprint $table) {
            $table->dropColumn('reminder_sent_at');
        });
    }
};