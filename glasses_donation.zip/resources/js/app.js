import './bootstrap';

import 'cropperjs/dist/cropper.css';
import Cropper from 'cropperjs';

window.Cropper = Cropper;